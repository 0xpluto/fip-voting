"use strict";
exports.id = 364;
exports.ids = [364];
exports.modules = {

/***/ 364:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ App),
/* harmony export */   options: () => (/* binding */ options)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var chart_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3767);
/* harmony import */ var react_chartjs_2__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(738);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([chart_js__WEBPACK_IMPORTED_MODULE_2__, react_chartjs_2__WEBPACK_IMPORTED_MODULE_3__, axios__WEBPACK_IMPORTED_MODULE_4__]);
([chart_js__WEBPACK_IMPORTED_MODULE_2__, react_chartjs_2__WEBPACK_IMPORTED_MODULE_3__, axios__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





chart_js__WEBPACK_IMPORTED_MODULE_2__.Chart.register(chart_js__WEBPACK_IMPORTED_MODULE_2__.CategoryScale, chart_js__WEBPACK_IMPORTED_MODULE_2__.LinearScale, chart_js__WEBPACK_IMPORTED_MODULE_2__.BarElement, chart_js__WEBPACK_IMPORTED_MODULE_2__.Title, chart_js__WEBPACK_IMPORTED_MODULE_2__.Tooltip, chart_js__WEBPACK_IMPORTED_MODULE_2__.Legend);
const options = {
    indexAxis: "y",
    elements: {
        bar: {
            borderWidth: 2
        }
    },
    responsive: true,
    plugins: {
        legend: {
            position: "right"
        },
        title: {
            display: true,
            text: "Previous Votes"
        }
    },
    scales: {
        x: {
            stacked: true
        },
        y: {
            stacked: true
        }
    }
};
function App() {
    const chartRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const [fips, setFips] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const [labels, setLabels] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [datasets, setDatasets] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const data = {
        labels,
        datasets
    };
    const fetchPreviousVotes = async ()=>{
        try {
            const res = await axios__WEBPACK_IMPORTED_MODULE_4__["default"].get(`${"http://18.116.124.40"}/filecoin/allconcludedvotes?network=calibration`);
            console.log(res.data);
            setFips(res.data);
            createLabels(res.data);
            createDatasets(res.data);
        } catch (error) {
            console.log(error);
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        fetchPreviousVotes();
    }, [
        fetchPreviousVotes
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const chart = chartRef.current;
        if (chart) {
            console.log("ChartJS", chart);
        }
    }, []);
    const footer = (tooltip)=>{
        console.log("TOOL TIP", tooltip);
        const keys = Object.keys(fips);
        const fip = fips[keys[tooltip[0].dataIndex]];
        const sum = fip.yay + fip.nay + fip.abstain;
        console.log("SUM", sum);
        console.log("FIPS", fips[keys[tooltip[0].dataIndex]]);
        return "Vote Power: " + parseInt(tooltip[0].formattedValue) / sum * 100 + "%";
    };
    const createLabels = (d)=>{
        let buffer = [];
        Object.keys(d).map((l)=>buffer.push(`FIP-${l}`));
        setLabels(buffer);
    };
    const createDatasets = (d)=>{
        let buffer = [];
        let yay = [];
        let nay = [];
        let abstain = [];
        Object.keys(d).map((l)=>{
            yay.push(d[l].yay);
            nay.push(d[l].nay);
            abstain.push(d[l].abstain);
        });
        setDatasets([
            {
                label: "Nay Votes",
                data: nay,
                // borderColor: "rgb(255, 99, 132)",
                backgroundColor: "rgba(249,53,53,0.8)"
            },
            {
                label: "Abstain Votes",
                data: abstain,
                // borderColor: "rgb(53, 162, 235)",
                backgroundColor: "rgba(249,171,53,0.8)"
            },
            {
                label: "Yay Votes",
                data: yay,
                // borderColor: "rgb(53, 162, 235)",
                backgroundColor: "rgba(53,249,53,0.8)"
            }
        ]);
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "md:px-56",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_chartjs_2__WEBPACK_IMPORTED_MODULE_3__.Bar, {
            ref: chartRef,
            options: {
                ...options,
                plugins: {
                    tooltip: {
                        callbacks: {
                            footer: footer
                        }
                    }
                }
            },
            data: data
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;