"use strict";
(() => {
var exports = {};
exports.id = 844;
exports.ids = [844];
exports.modules = {

/***/ 2985:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   config: () => (/* binding */ config),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   getServerSideProps: () => (/* binding */ getServerSideProps),
/* harmony export */   getStaticPaths: () => (/* binding */ getStaticPaths),
/* harmony export */   getStaticProps: () => (/* binding */ getStaticProps),
/* harmony export */   reportWebVitals: () => (/* binding */ reportWebVitals),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   unstable_getServerProps: () => (/* binding */ unstable_getServerProps),
/* harmony export */   unstable_getServerSideProps: () => (/* binding */ unstable_getServerSideProps),
/* harmony export */   unstable_getStaticParams: () => (/* binding */ unstable_getStaticParams),
/* harmony export */   unstable_getStaticPaths: () => (/* binding */ unstable_getStaticPaths),
/* harmony export */   unstable_getStaticProps: () => (/* binding */ unstable_getStaticProps)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3185);
/* harmony import */ var next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7182);
/* harmony import */ var private_next_pages_vote_fip_tsx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7381);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([private_next_pages_vote_fip_tsx__WEBPACK_IMPORTED_MODULE_2__]);
private_next_pages_vote_fip_tsx__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

        // Next.js Route Loader
        
        

        // Import the userland code.
        

        // Re-export the component (should be the default export).
        /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_1__/* .hoist */ .l)(private_next_pages_vote_fip_tsx__WEBPACK_IMPORTED_MODULE_2__, "default"));

        // Re-export methods.
        const getStaticProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_1__/* .hoist */ .l)(private_next_pages_vote_fip_tsx__WEBPACK_IMPORTED_MODULE_2__, "getStaticProps")
        const getStaticPaths = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_1__/* .hoist */ .l)(private_next_pages_vote_fip_tsx__WEBPACK_IMPORTED_MODULE_2__, "getStaticPaths")
        const getServerSideProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_1__/* .hoist */ .l)(private_next_pages_vote_fip_tsx__WEBPACK_IMPORTED_MODULE_2__, "getServerSideProps")
        const config = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_1__/* .hoist */ .l)(private_next_pages_vote_fip_tsx__WEBPACK_IMPORTED_MODULE_2__, "config")
        const reportWebVitals = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_1__/* .hoist */ .l)(private_next_pages_vote_fip_tsx__WEBPACK_IMPORTED_MODULE_2__, "reportWebVitals")

        // Re-export legacy methods.
        const unstable_getStaticProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_1__/* .hoist */ .l)(private_next_pages_vote_fip_tsx__WEBPACK_IMPORTED_MODULE_2__, "unstable_getStaticProps")
        const unstable_getStaticPaths = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_1__/* .hoist */ .l)(private_next_pages_vote_fip_tsx__WEBPACK_IMPORTED_MODULE_2__, "unstable_getStaticPaths")
        const unstable_getStaticParams = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_1__/* .hoist */ .l)(private_next_pages_vote_fip_tsx__WEBPACK_IMPORTED_MODULE_2__, "unstable_getStaticParams")
        const unstable_getServerProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_1__/* .hoist */ .l)(private_next_pages_vote_fip_tsx__WEBPACK_IMPORTED_MODULE_2__, "unstable_getServerProps")
        const unstable_getServerSideProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_1__/* .hoist */ .l)(private_next_pages_vote_fip_tsx__WEBPACK_IMPORTED_MODULE_2__, "unstable_getServerSideProps")

        // Create and export the route module that will be consumed.
        const options = {"definition":{"kind":"PAGES","page":"/vote/[fip]","pathname":"/vote/[fip]","bundlePath":"","filename":""}}
        const routeModule = new (next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0___default())({ ...options, userland: private_next_pages_vote_fip_tsx__WEBPACK_IMPORTED_MODULE_2__ })
        
        
    
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 750:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);

const ContainerDiv = ({ children })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: " bg-white  dark:bg-slate-800 rounded-md shadow-md p-3 md:p-5",
        children: children
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ContainerDiv);


/***/ }),

/***/ 3754:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Z: () => (/* binding */ components_ViewVote)
});

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: external "string"
const external_string_namespaceObject = require("string");
var external_string_default = /*#__PURE__*/__webpack_require__.n(external_string_namespaceObject);
;// CONCATENATED MODULE: ./src/components/ViewVote.tsx



const formatString = (str)=>{
    const arr = str.split(" ");
    let buffer = [];
    for(let i in arr){
        if (arr[i].length > 3) {
            buffer.push(external_string_default()(arr[i]).capitalize().s);
        } else {
            buffer.push(arr[i]);
        }
    }
    return buffer.join(" ");
};
const ViewVote = ({ title, description, status, author, type })=>{
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "flex flex-col gap-2 justify-start",
        children: [
            /*#__PURE__*/ jsx_runtime.jsx("div", {
                className: "text-sm text-neutral-400 mb-3",
                children: "Latest Vote Results "
            }),
            /*#__PURE__*/ jsx_runtime.jsx("div", {
                className: "font-bold",
                children: title.toUpperCase()
            }),
            /*#__PURE__*/ jsx_runtime.jsx("div", {
                children: formatString(description)
            }),
            /*#__PURE__*/ jsx_runtime.jsx("div", {
                children: formatString(status)
            }),
            /*#__PURE__*/ jsx_runtime.jsx("div", {
                children: formatString(author)
            }),
            /*#__PURE__*/ jsx_runtime.jsx("div", {
                children: formatString(type)
            })
        ]
    });
};
/* harmony default export */ const components_ViewVote = (ViewVote);


/***/ }),

/***/ 4222:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var wagmi__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8998);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9648);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3590);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([wagmi__WEBPACK_IMPORTED_MODULE_2__, axios__WEBPACK_IMPORTED_MODULE_4__, react_toastify__WEBPACK_IMPORTED_MODULE_5__]);
([wagmi__WEBPACK_IMPORTED_MODULE_2__, axios__WEBPACK_IMPORTED_MODULE_4__, react_toastify__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






const Vote = ()=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
    const [message, setMessage] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const { data, isError, isLoading, isSuccess, signMessage } = (0,wagmi__WEBPACK_IMPORTED_MODULE_2__.useSignMessage)({
        message: `${message}: FIP-${parseInt(router.query.fip?.slice(-2))}`,
        onSettled (data, error) {
            console.log("Settled", {
                data,
                error
            });
            axios__WEBPACK_IMPORTED_MODULE_4__["default"].post(`${"http://18.116.124.40"}/filecoin/vote?fip_number=${parseInt(router.query.fip?.slice(-2))}&network=calibration`, {
                signature: data,
                message: `${message}: FIP-${parseInt(router.query.fip?.slice(-2))}`
            }, {
                headers: {
                    "Content-Type": "application/json"
                }
            }).then(function(response) {
                react_toastify__WEBPACK_IMPORTED_MODULE_5__.toast.success("Vote casted successfully", {
                    position: "top-center",
                    autoClose: 5000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                    theme: "light"
                });
            }).catch(function(error) {
                console.log(error);
                react_toastify__WEBPACK_IMPORTED_MODULE_5__.toast.error(error.message, {
                    position: "top-center",
                    autoClose: 5000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                    theme: "light"
                });
            });
        }
    });
    console.log(`${message}: FIP-${parseInt(router.query.fip?.slice(-2))}`);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "text-sm text-neutral-400 mb-3",
                children: "Choose Vote"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-col gap-4",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: message === "NAY" ? " border-4 border-neutral-800  dark:border-slate-200 rounded-md text-center pt-3 " : "hover:border-4 rounded-md text-center pt-3 ",
                        style: {
                            height: "50px",
                            width: "100%",
                            background: "#ED2939"
                        },
                        onClick: ()=>setMessage("NAY"),
                        children: "NAY"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: message === "ABSTAIN" ? "border-4 border-neutral-800 dark:border-slate-200 rounded-md text-center items-center pt-3" : "hover:border-4 rounded-md text-center pt-3",
                        style: {
                            height: "50px",
                            width: "100%",
                            background: "#FDDA0D"
                        },
                        onClick: ()=>setMessage("ABSTAIN"),
                        children: "ABSTAIN"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: message === "YAY" ? "border-4 border-neutral-800  dark:border-slate-200 rounded-md text-center pt-3" : "hover:border-4 rounded-md text-center pt-3",
                        style: {
                            height: "50px",
                            width: "100%",
                            background: "#228B22"
                        },
                        onClick: ()=>setMessage("YAY"),
                        children: "YAY"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                        onClick: ()=>signMessage(),
                        className: "w-100 bg-slate-400 rounded-sm py-2",
                        children: "Vote"
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Vote);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5258:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (/* binding */ StartVote)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var wagmi__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8998);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9648);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3590);
/* harmony import */ var octokit__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4287);
/* harmony import */ var octokit__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(octokit__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([wagmi__WEBPACK_IMPORTED_MODULE_2__, axios__WEBPACK_IMPORTED_MODULE_3__, react_toastify__WEBPACK_IMPORTED_MODULE_4__]);
([wagmi__WEBPACK_IMPORTED_MODULE_2__, axios__WEBPACK_IMPORTED_MODULE_3__, react_toastify__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







const octokit = new octokit__WEBPACK_IMPORTED_MODULE_5__.Octokit({
    auth: process.env.NODE_PUBLIC_OCTO
});
function StartVote() {
    const [fips, setFips] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [isStarter, setIsStarter] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [starters, setStarters] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const { address, isConnected } = (0,wagmi__WEBPACK_IMPORTED_MODULE_2__.useAccount)();
    const [FIP, setFip] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("FIP-1");
    const { data, isError, isLoading, isSuccess, signMessage } = (0,wagmi__WEBPACK_IMPORTED_MODULE_2__.useSignMessage)({
        message: FIP,
        onSettled (data, error) {
            console.log("Settled", {
                data,
                error
            });
            axios__WEBPACK_IMPORTED_MODULE_3__["default"].post(`${"http://18.116.124.40"}/filecoin/startvote?network=calibration`, {
                signature: data,
                message: FIP
            }, {
                headers: {
                    "Content-Type": "application/json"
                }
            }).then(function(response) {
                console.log(response);
                react_toastify__WEBPACK_IMPORTED_MODULE_4__.toast.success("Voting Started Successfully", {
                    position: "top-center",
                    autoClose: 5000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                    theme: "light"
                });
            }).catch(function(error) {
                console.log(error);
                react_toastify__WEBPACK_IMPORTED_MODULE_4__.toast.error(error.message, {
                    position: "top-center",
                    autoClose: 5000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                    theme: "light"
                });
            });
        }
    });
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        fetchRepo();
        if (starters.includes(address?.toLowerCase())) {
            setIsStarter(true);
        }
        if (starters.length == 0) {
            fetchVoteStarters();
        }
    }, [
        address,
        starters
    ]);
    const fetchVoteStarters = async ()=>{
        try {
            const res = await axios__WEBPACK_IMPORTED_MODULE_3__["default"].get(`${"http://18.116.124.40"}/filecoin/voterstarters?network=calibration`);
            console.log(res);
            setStarters(res.data);
        } catch (error) {
            console.log(error);
        }
    };
    const fetchRepo = async ()=>{
        console.log("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");
        try {
            const buffer = [];
            const { data } = await axios__WEBPACK_IMPORTED_MODULE_3__["default"].get("https://api.github.com/repos/filecoin-project/FIPS/git/trees/cad110e51558a00945e3922895cd89659b673852");
            data.tree.map((d)=>{
                buffer.push(d.path.slice(0, 3).toUpperCase() + "-" + parseInt(d.path.slice(4, 8)));
            });
            setFips(buffer);
        } catch (error) {
            console.log(error);
        }
    };
    console.log(fips);
    if (isStarter) return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex flex-row items-center  ",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                className: "",
                children: [
                    "Choose FIP:",
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("select", {
                        className: "dark:bg-slate-600 mx-3 rounded-md p-2",
                        value: FIP,
                        onChange: (e)=>setFip(e.target.value),
                        children: fips.map((f)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: f,
                                children: f
                            }, f))
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                onClick: ()=>signMessage(),
                className: "bg-green-500 shadow-md  py-2 px-4 rounded-md",
                children: "Start Votes"
            })
        ]
    });
    else return null;
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7442:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (/* binding */ RegisterVoteStarter)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var wagmi__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8998);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9648);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3590);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([wagmi__WEBPACK_IMPORTED_MODULE_2__, axios__WEBPACK_IMPORTED_MODULE_3__, react_toastify__WEBPACK_IMPORTED_MODULE_4__]);
([wagmi__WEBPACK_IMPORTED_MODULE_2__, axios__WEBPACK_IMPORTED_MODULE_3__, react_toastify__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






function RegisterVoteStarter() {
    const [isStarter, setIsStarter] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [starters, setStarters] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const { address, isConnected } = (0,wagmi__WEBPACK_IMPORTED_MODULE_2__.useAccount)();
    const [FIP, setFip] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("FIP-1");
    const [newVoteStarter, setNewVoteStarter] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const { data, isError, isLoading, isSuccess, signMessage } = (0,wagmi__WEBPACK_IMPORTED_MODULE_2__.useSignMessage)({
        message: newVoteStarter,
        onSettled (data, error) {
            console.log("Settled", {
                data,
                error
            });
            axios__WEBPACK_IMPORTED_MODULE_3__["default"].post(`${"http://18.116.124.40"}/filecoin/registerstarter?network=calibration`, {
                signature: data,
                message: newVoteStarter
            }, {
                headers: {
                    "Content-Type": "application/json"
                }
            }).then(function(response) {
                console.log(response);
                react_toastify__WEBPACK_IMPORTED_MODULE_4__.toast.success("New Vote Starter Submitted Successfully", {
                    position: "top-center",
                    autoClose: 5000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                    theme: "light"
                });
            }).catch(function(error) {
                console.log(error);
                react_toastify__WEBPACK_IMPORTED_MODULE_4__.toast.error(error.message, {
                    position: "top-center",
                    autoClose: 5000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                    theme: "light"
                });
            });
        }
    });
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (starters.includes(address?.toLowerCase())) {
            setIsStarter(true);
        }
        if (starters.length == 0) {
            fetchVoteStarters();
        }
    }, [
        address,
        starters
    ]);
    const fetchVoteStarters = async ()=>{
        try {
            const res = await axios__WEBPACK_IMPORTED_MODULE_3__["default"].get(`${"http://18.116.124.40"}/filecoin/voterstarters?network=calibration`);
            console.log(res);
            setStarters(res.data);
        } catch (error) {
            console.log(error);
        }
    };
    if (isStarter) return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex flex-row items-center ",
        style: {
            padding: "8px"
        },
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                className: "",
                children: [
                    "Input new vote starter:",
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                        type: "text",
                        value: newVoteStarter,
                        onChange: (e)=>setNewVoteStarter(e.target.value),
                        style: {
                            border: "2px solid gray",
                            borderRadius: "6px"
                        }
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                onClick: ()=>signMessage(),
                className: "bg-green-500 shadow-md  py-2 px-4 rounded-md",
                children: "Submit starter"
            })
        ]
    });
    else return null;
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7381:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Home),
/* harmony export */   getServerSideProps: () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_ViewVote__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3754);
/* harmony import */ var _components_Vote__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4222);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9648);
/* harmony import */ var markdown_it__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9653);
/* harmony import */ var markdown_it__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(markdown_it__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_countdown__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4449);
/* harmony import */ var react_countdown__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_countdown__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _components_ContainerDiv__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(750);
/* harmony import */ var _components_startVote__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5258);
/* harmony import */ var _components_voteStarter__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(7442);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(5152);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_11__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Vote__WEBPACK_IMPORTED_MODULE_3__, axios__WEBPACK_IMPORTED_MODULE_4__, _components_startVote__WEBPACK_IMPORTED_MODULE_9__, _components_voteStarter__WEBPACK_IMPORTED_MODULE_10__]);
([_components_Vote__WEBPACK_IMPORTED_MODULE_3__, axios__WEBPACK_IMPORTED_MODULE_4__, _components_startVote__WEBPACK_IMPORTED_MODULE_9__, _components_voteStarter__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/* __next_internal_client_entry_do_not_use__ default,getServerSideProps auto */ 


// import TotalVotes from "../../components/TotalVotes";
// import VotingPower from "../../components/VotingPower";








// import WalletVotingPower from "@/components/WalletVotingPower";

const WalletVotingPower = next_dynamic__WEBPACK_IMPORTED_MODULE_11___default()(()=>__webpack_require__.e(/* import() */ 909).then(__webpack_require__.bind(__webpack_require__, 6909)), {
    loadableGenerated: {
        modules: [
            "vote\\[fip].tsx -> " + "@/components/WalletVotingPower"
        ]
    }
});
const VotingPower = next_dynamic__WEBPACK_IMPORTED_MODULE_11___default()(null, {
    loadableGenerated: {
        modules: [
            "vote\\[fip].tsx -> " + "../../components/VotingPower"
        ]
    },
    ssr: false
});
const TotalVotes = next_dynamic__WEBPACK_IMPORTED_MODULE_11___default()(null, {
    loadableGenerated: {
        modules: [
            "vote\\[fip].tsx -> " + "../../components/TotalVotes"
        ]
    },
    ssr: false
});
const PreviousVotes = next_dynamic__WEBPACK_IMPORTED_MODULE_11___default()(()=>__webpack_require__.e(/* import() */ 364).then(__webpack_require__.bind(__webpack_require__, 364)), {
    loadableGenerated: {
        modules: [
            "vote\\[fip].tsx -> " + "../../components/PreviousVotes"
        ]
    }
});
function Home(props) {
    const [active, setActive] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [time, setTime] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    const [votes, setVotes] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
        yay: 0,
        nay: 0,
        abstain: 0,
        yay_storage_size: 0,
        nay_storage_size: 0,
        abstain_storage_size: 0
    });
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_6__.useRouter)();
    const md = new (markdown_it__WEBPACK_IMPORTED_MODULE_5___default())();
    const children = md.parse(props.data, {})[2].children;
    const [error, setError] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        fetchVotes();
    }, []);
    const fetchVotes = async ()=>{
        setActive(false);
        try {
            const res = await axios__WEBPACK_IMPORTED_MODULE_4__["default"].get(`http://18.116.124.40/filecoin/vote?fip_number=${parseInt(router.query.fip?.slice(-2))}&network=calibration`);
            console.log(typeof res.data);
            console.log("INSDIE ", res.data);
            console.log(Object.hasOwn(res.data, "yay"));
            if (Object.hasOwn(res.data, "yay")) {
                setVotes(res.data);
            } else {
                setActive(true);
                setTime(res.data);
            }
        } catch (error) {
            // console.log(error.response.status);
            // setError(error.response.status);
            console.log(error);
        }
    };
    if (props.data === "notfound") {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ContainerDiv__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
            children: "No such FIP"
        });
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "my-4",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ContainerDiv__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex flex-row justify-between",
                        children: [
                            active && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_countdown__WEBPACK_IMPORTED_MODULE_7___default()), {
                                date: Date.now() + time * 1000,
                                onComplete: ()=>fetchVotes()
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_startVote__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {}),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_voteStarter__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {})
                        ]
                    })
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "grid grid-cols-1 md:grid-cols-3 gap-4",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ContainerDiv__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ViewVote__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                            title: props && children[0].content,
                            description: props && children[2].content,
                            status: props && children[4].content,
                            author: props && children[8].content,
                            type: props && children[6].content
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ContainerDiv__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                        children: !active ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TotalVotes, {
                            votes: votes
                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Vote__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {})
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ContainerDiv__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                        children: active ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(WalletVotingPower, {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(VotingPower, {
                            // yes={(votes as any).yay_storage_size}
                            // no={(votes as any).nay_storage_size}
                            // abstain={(votes as any).abstain_storage_size}
                            data: votes
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "mt-4",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ContainerDiv__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(PreviousVotes, {})
                })
            })
        ]
    });
}
async function getServerSideProps(ctx) {
    // Fetch data from external API
    const { fip } = ctx.query;
    try {
        const res = await axios__WEBPACK_IMPORTED_MODULE_4__["default"].get(`https://raw.githubusercontent.com/filecoin-project/FIPs/master/FIPS/${fip}.md`);
        const data = res.data;
        // Pass data to the page via props
        return {
            props: {
                data
            }
        };
    } catch (error) {
        return {
            props: {
                data: "notfound"
            }
        };
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9653:
/***/ ((module) => {

module.exports = require("markdown-it");

/***/ }),

/***/ 3076:
/***/ ((module) => {

module.exports = require("next/dist/server/future/route-modules/route-module.js");

/***/ }),

/***/ 3100:
/***/ ((module) => {

module.exports = require("next/dist/server/render.js");

/***/ }),

/***/ 5832:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 4287:
/***/ ((module) => {

module.exports = require("octokit");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 4449:
/***/ ((module) => {

module.exports = require("react-countdown");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 3767:
/***/ ((module) => {

module.exports = import("chart.js");;

/***/ }),

/***/ 738:
/***/ ((module) => {

module.exports = import("react-chartjs-2");;

/***/ }),

/***/ 3590:
/***/ ((module) => {

module.exports = import("react-toastify");;

/***/ }),

/***/ 8998:
/***/ ((module) => {

module.exports = import("wagmi");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [812,152], () => (__webpack_exec__(2985)));
module.exports = __webpack_exports__;

})();