import React, { FunctionComponent } from "react";

const Footer: FunctionComponent = () => {
  return <div></div>;
};

export default Footer;
