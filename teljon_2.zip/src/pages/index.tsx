import { PropsWithChildren, useEffect } from "react";
import ViewVote from "../components/ViewVote";
import TotalVotes from "../components/TotalVotes";
import VotingPower from "../components/VotingPower";
import ContainerDiv from "@/components/ContainerDiv";
import axios from "axios";

export default function Home() {
  useEffect(() => {
    getActiveFIP();
  });

  const getActiveFIP = async () => {
    try {
      const res = await axios.get(
        `${process.env.NEXT_PUBLIC_API}/filecoin/activevotes?network=calibration`
      );
      console.log(res);
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <ContainerDiv>
          {/* <ViewVote
            title="FIP 312"
            description="Lorem ipsum dolor sit amet consectetur adipisicing elit. Debitis labore dignissimos quae illum dolore. Reiciendis nisi, repellat sequi officia aspernatur hic illum assumenda similique explicabo cum quidem commodi ipsam iusto."
          /> */}
          Anas
        </ContainerDiv>
        <ContainerDiv>{/* <TotalVotes /> */}Shad</ContainerDiv>
        <ContainerDiv>
          <VotingPower yes={38} no={68} abstain={62} />
        </ContainerDiv>
      </div>
    </>
  );
}
